import requests
from bs4 import BeautifulSoup
import re
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud


def fetch_html(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # 检查请求是否成功
        return response.text
    except requests.RequestException as e:
        print(f"Error fetching {url}: {e}")
        return None


def clean_text(text):
    # 清理文本中的多余空格和换行符
    cleaned_text = ' '.join(text.split())
    cleaned_text = re.split(r'\s*•\s*', cleaned_text)
    cleaned_text = [item.strip() for item in cleaned_text if item.strip()]
    return cleaned_text


def extract_article_info(html):
    soup = BeautifulSoup(html, 'html.parser')
    data = []

    articles = soup.find_all('article', class_='overview-card-wrapper group/repo')
    for article in articles:
        article_data = {}

        # 提取标题部分
        header = article.find('header')
        if header:
            title = header.get('title')
            if title:
                article_data["Code name"] = title

        # 提取描述部分
        description = article.find('div', class_='mr-1 flex items-center overflow-hidden whitespace-nowrap text-sm leading-tight text-gray-400')
        if description:
            description_text = clean_text(description.text)
            if len(description_text) >= 4:
                article_data["Model Type"] = description_text[0]
                article_data['Updated Time'] = description_text[1]
                article_data["Downloads"] = description_text[2]
                article_data["Likes"] = description_text[3]

        # 提取更新时间部分
        time_tag = article.find('time')
        if time_tag:
            updated_time = time_tag.get('datetime')
            if updated_time:
                article_data["Upload Time"] = updated_time.replace('T', ' ')

        # 将当前文章的数据添加到列表中
        data.append(article_data)

    return data


def convert_to_int(value):
    if pd.isna(value):
        return 0
    value = value.lower()  # 将值转换为小写
    if 'k' in value:
        return int(float(value.replace('k', '')) * 1000)
    elif 'm' in value:
        return int(float(value.replace('m', '')) * 1000000)
    else:
        return int(value.replace(',', ''))


def analyze_and_visualize_data(df):
    # 将下载量和喜欢次数转换为整数
    df['Downloads'] = df['Downloads'].apply(convert_to_int)
    df['Likes'] = df['Likes'].apply(convert_to_int)

    # 打印部分数据进行检查
    print(df.head())

    # 统计 Model Type 出现的次数并保存为 CSV 文件
    model_type_counts = df['Model Type'].value_counts().reset_index()
    model_type_counts.columns = ['Model Type', 'Count']
    model_type_counts.to_csv('./data/model_type_counts.csv', index=False)

    # 可视化 Model Type 出现的次数
    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x='Model Type', palette='viridis')
    plt.xticks(rotation=45)
    plt.title('Frequency of Model Types')
    plt.tight_layout()
    plt.show()

    # 可视化下载量最多的前10个模型
    top_downloads = df.nlargest(10, 'Downloads')
    plt.figure(figsize=(10, 6))
    sns.barplot(data=top_downloads, x='Downloads', y='Code name', palette='viridis')
    plt.title('Top 10 Models by Downloads')
    plt.tight_layout()
    plt.show()

    # 可视化喜欢次数最多的前10个模型
    top_likes = df.nlargest(10, 'Likes')
    plt.figure(figsize=(10, 6))
    sns.barplot(data=top_likes, x='Likes', y='Code name', palette='viridis')
    plt.title('Top 10 Models by Likes')
    plt.tight_layout()
    plt.show()

    # 热点分析：生成词云图
    generate_wordcloud(df['Model Type'].dropna().str.cat(sep=' '))


def generate_wordcloud(text):
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)
    plt.figure(figsize=(10, 6))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.title('Word Cloud of Model Types')
    plt.show()


def main():
    url = 'https://huggingface.co/models'  # 替换为你要抓取的网页链接
    html = fetch_html(url)
    if html:
        extracted_data = extract_article_info(html)
        df = pd.DataFrame(extracted_data)

        # 将DataFrame保存到CSV文件
        df.to_csv('./data/hf_models_data.csv', index=False)

        # 进行数据分析和可视化
        analyze_and_visualize_data(df)


if __name__ == "__main__":
    main()
